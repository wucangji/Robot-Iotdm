##How to start the script:
`python CreateRSSIdata.py`

###input 
1. you can enter both localhost or a remote iotdm
2. The path of the tree, you only need to provision that CSE fisrt, no need to create all the path. For example, if you enter:   
`InCSE2/layer1/layer2`  
in your IOTDM, you only need to provision "InCSE2", no need to create layer1 and layer2, the script will check that path, if the resource does not exist, the script will create that for you.

